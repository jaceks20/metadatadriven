create procedure dwh.sp_LoadCustomer
AS
-- Merge Silver with Gold using MERGE statement
MERGE dwh.DimCustomer AS T
USING [DE_LH_100_200_PROJECT].dbo.dimcustomer AS S
    ON  T.CustomerKey = S.CustomerKey      -- or CustomerAlternateKey
WHEN MATCHED THEN
    UPDATE SET
          T.CommuteDistance      = S.CommuteDistance
        , T.DateFirstPurchase    = S.DateFirstPurchase
        , T.Phone                = S.Phone
        , T.NumberCarsOwned      = S.NumberCarsOwned
        , T.AddressLine1         = S.AddressLine1
        , T.HouseOwnerFlag       = S.HouseOwnerFlag
        , T.FrenchOccupation     = S.FrenchOccupation
        , T.SpanishOccupation    = S.SpanishOccupation
        , T.EnglishOccupation    = S.EnglishOccupation
        , T.FrenchEducation      = S.FrenchEducation
        , T.SpanishEducation     = S.SpanishEducation
        , T.EnglishEducation     = S.EnglishEducation
        , T.NumberChildrenAtHome = S.NumberChildrenAtHome
        , T.TotalChildren        = S.TotalChildren
        , T.YearlyIncome         = S.YearlyIncome
        , T.EmailAddress         = S.EmailAddress
        , T.Gender               = S.Gender
        , T.Suffix               = S.Suffix
        , T.MaritalStatus        = S.MaritalStatus
        , T.BirthDate            = S.BirthDate
        , T.NameStyle            = S.NameStyle
        , T.LastName             = S.LastName
        , T.MiddleName           = S.MiddleName
        , T.FirstName            = S.FirstName
        , T.Title                = S.Title
        , T.CustomerAlternateKey = S.CustomerAlternateKey
        , T.GeographyKey         = S.GeographyKey
        , T.FullName             = S.FullName
WHEN NOT MATCHED BY TARGET THEN
    INSERT (
          CustomerKey
        , CommuteDistance
        , DateFirstPurchase
        , Phone
        , NumberCarsOwned
        , AddressLine1
        , HouseOwnerFlag
        , FrenchOccupation
        , SpanishOccupation
        , EnglishOccupation
        , FrenchEducation
        , SpanishEducation
        , EnglishEducation
        , NumberChildrenAtHome
        , TotalChildren
        , YearlyIncome
        , EmailAddress
        , Gender
        , Suffix
        , MaritalStatus
        , BirthDate
        , NameStyle
        , LastName
        , MiddleName
        , FirstName
        , Title
        , CustomerAlternateKey
        , GeographyKey
        , FullName
    )
    VALUES (
          S.CustomerKey
        , S.CommuteDistance
        , S.DateFirstPurchase
        , S.Phone
        , S.NumberCarsOwned
        , S.AddressLine1
        , S.HouseOwnerFlag
        , S.FrenchOccupation
        , S.SpanishOccupation
        , S.EnglishOccupation
        , S.FrenchEducation
        , S.SpanishEducation
        , S.EnglishEducation
        , S.NumberChildrenAtHome
        , S.TotalChildren
        , S.YearlyIncome
        , S.EmailAddress
        , S.Gender
        , S.Suffix
        , S.MaritalStatus
        , S.BirthDate
        , S.NameStyle
        , S.LastName
        , S.MiddleName
        , S.FirstName
        , S.Title
        , S.CustomerAlternateKey
        , S.GeographyKey
        , S.FullName
    );

-- update max value in Bronze metadata definition for incremental load
update meta.TablesBronze set DeltaColumnMaxValue=(select max(CustomerKey) from [DE_LH_100_200_PROJECT].dbo.dimcustomer) where Id=3