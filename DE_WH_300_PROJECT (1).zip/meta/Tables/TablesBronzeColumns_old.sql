CREATE TABLE [meta].[TablesBronzeColumns_old] (

	[TablesBronzeId] int NULL, 
	[ColumnName] varchar(100) NULL, 
	[IsActive] int NULL
);