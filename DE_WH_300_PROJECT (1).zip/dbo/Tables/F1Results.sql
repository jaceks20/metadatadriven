CREATE TABLE [dbo].[F1Results] (

	[Name] varchar(8000) NULL, 
	[Position] int NULL, 
	[City] varchar(8000) NULL, 
	[RaceDay] date NULL, 
	[GrandPrix] varchar(8000) NULL
);