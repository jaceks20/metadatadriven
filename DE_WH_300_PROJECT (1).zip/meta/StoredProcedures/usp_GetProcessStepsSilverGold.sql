CREATE   procedure [meta].[usp_GetProcessStepsSilverGold] (@Layer varchar(10))
as 
DECLARE @UnfinishedSteps INT;
select @UnfinishedSteps=count(1) from meta.ProcessingSteps where isnull(Status,-1)=-1 and (Layer=@Layer or Layer='Bronze') and IsCurrent=1

if @UnfinishedSteps>0
BEGIN
-- delete from temporary table with Steps statuses
delete from meta.tmp_ProcessingSteps where Layer<>'Bronze'

END
ELSE
BEGIN
-- delete from temporary table with Steps statuses
delete from meta.tmp_ProcessingSteps where Layer<>'Bronze'

-- Update flag isCurrent to 0 - means historical load and a new one will be created
update meta.ProcessingSteps set IsCurrent=0 where Layer=@Layer;

-- generate steps
insert into [meta].[ProcessingSteps]([SourceObjectName],[TargetTableName],[PartitionedColumn],[Layer],[ColumnNames],[ArtifactName], [OrderNo],[ObjectType],[StepCreationDate],[IsCurrent],[TableType],[TableId],[ContainerPath])
(SELECT 
    tb.SourceObjectName,
    tsg.TargetTableName,
    tsg.PartitionedColumn,
    @Layer AS Layer,
   STRING_AGG(
                 CASE 
                    WHEN @Layer = 'Silver' THEN tc.SilverLogic
                    WHEN @Layer = 'Gold'   THEN tc.GoldLogic
                END,
           ', '
    ) AS ColumnsLogic,
    tsg.ArtifactName,
    tsg.OrderNo,
    tsg.ObjectType,
    CAST(GETDATE() AS datetime2(2)) AS CreatedDate,
    tsg.IsActive,
    tsg.TableType,
    tsg.Id,
    ps.ContainerPath
FROM meta.TablesSilverGold tsg
LEFT JOIN meta.TableColumns tc 
    ON tsg.SourceTableNameId = tc.TablesBronzeId
LEFT JOIN meta.TablesBronze tb
    ON tb.Id = tc.TablesBronzeId
LEFT JOIN meta.ProcessingSteps ps 
    ON tsg.SourceTableNameId = ps.TableId
   AND ps.IsCurrent = 1
   AND ps.Layer = 'Bronze'
WHERE tsg.IsActive = 1
  AND tsg.Layer = @Layer
  AND (
        tc.TablesBronzeId IS NULL
        OR (
            (@Layer = 'Silver' AND tc.SilverIsActive = 1 AND ps.ContainerPath is not null)
         OR (@Layer = 'Gold'   AND tc.GoldIsActive   = 1)
        )
      )
GROUP BY 
    tb.SourceObjectName,
    tsg.TargetTableName,
    tsg.PartitionedColumn,
    tsg.ArtifactName,
    tsg.OrderNo,
    tsg.ObjectType,
    tsg.TableType,
    tsg.Id,
    ps.ContainerPath,
    tsg.IsActive)
END