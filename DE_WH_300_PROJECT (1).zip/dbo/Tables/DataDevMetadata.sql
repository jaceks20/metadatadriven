CREATE TABLE [dbo].[DataDevMetadata] (

	[table_schema] varchar(8000) NULL, 
	[table_name] varchar(8000) NULL, 
	[column_name] varchar(8000) NULL
);