CREATE TABLE [meta].[tmp_ProcessingSteps_old] (

	[TableId] varchar(6) NOT NULL, 
	[Status] int NULL, 
	[CreateDate] datetime2(2) NULL, 
	[Layer] varchar(10) NULL
);