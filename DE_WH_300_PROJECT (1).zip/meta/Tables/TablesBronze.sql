CREATE TABLE [meta].[TablesBronze] (

	[Id] bigint IDENTITY NOT NULL, 
	[SourceSystemName] varchar(100) NULL, 
	[SourceSystemType] varchar(100) NULL, 
	[SourceContainerName] varchar(50) NULL, 
	[SourceObjectName] varchar(255) NULL, 
	[TargetTableName] varchar(255) NULL, 
	[ImportType] varchar(50) NULL, 
	[PartitionedColumn] varchar(100) NULL, 
	[AdditionalFilters] varchar(200) NULL, 
	[DeltaColumnName] varchar(100) NULL, 
	[DeltaColumnType] varchar(100) NULL, 
	[DeltaColumnMaxValue] varchar(100) NULL, 
	[IsActive] int NULL
);