CREATE TABLE [meta].[TablesSilverGold_Old] (

	[Id] int NULL, 
	[SourceTableName] varchar(100) NULL, 
	[TargetTableName] varchar(255) NULL, 
	[PartitionedColumn] varchar(100) NULL, 
	[Layer] varchar(10) NULL, 
	[ArtifactName] varchar(100) NULL, 
	[OrderNo] varchar(100) NULL, 
	[ObjectType] varchar(10) NULL, 
	[IsActive] int NULL, 
	[TableType] varchar(10) NOT NULL
);