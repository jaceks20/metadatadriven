CREATE   procedure [meta].[usp_GetProcessStepsBronze]
as 

DECLARE @UnfinishedSteps INT;
select @UnfinishedSteps=count(1) from meta.ProcessingSteps where isnull(Status,0)=0 and IsCurrent=1 and Layer='Bronze'

if @UnfinishedSteps>0
BEGIN

-- truncate temporary table with Steps statuses
delete from meta.tmp_ProcessingSteps where Layer='Bronze'

END
ELSE
BEGIN
-- truncate temporary table with Steps statuses
delete from meta.tmp_ProcessingSteps where Layer='Bronze'

-- Update flag isCurrent to 0 - means historical load and a new one will be created
update meta.ProcessingSteps set IsCurrent=0 where Layer='Bronze';

-- insert data from configuration to ProcessingSteps table. If no column detected from TablesBronzeColumns means that we must read all of them like *.
insert into meta.ProcessingSteps([SourceSystemName],[SourceSystemType],[SourceContainerName],[SourceObjectName],[ColumnNames],[TargetTableName],[PartitionedColumn],[AdditionalFilters],[TableId],[Layer],[TableType],[ImportType],[DeltaColumnName],[DeltaColumnMaxValue],[StepCreationDate],[StepModificationDate],[Status],IsCurrent,ContainerPath)
SELECT 
	SourceSystemName,
    SourceSystemType,
    SourceContainerName, 
    SourceObjectName,
    ISNULL(STRING_AGG(ColumnName, ', '),'*')																		AS ColumnNames,
    TargetTableName,
    PartitionedColumn,
    AdditionalFilters,
    Id,
	'Bronze'																										AS Layer,
    'raw'																											AS ObjectType,
    ImportType,
	DeltaColumnName,
	case when (DeltaColumnType='int' and DeltaColumnMaxValue is null) then '-1' 
		 when (upper(DeltaColumnType)='DATE' and DeltaColumnMaxValue is null) then '1900-01-01'  
		 else  DeltaColumnMaxValue end																				AS DeltaColumnMaxValue,
	CAST(GETDATE() AS DATETIME2(2))																					AS StepCreationDate,
	NULL																											AS StepModificationDate,
    NULL																											AS Status,
	1																												AS IsCurrent,
	SourceSystemName+'/'+SourceContainerName+'/'+convert(char(10),GetDate(),126)+'/'+TargetTableName				AS ContainerPath
FROM [meta].[TablesBronze] tb
LEFT JOIN [meta].[TableColumns] tbc 
    ON tb.Id = tbc.TablesBronzeId 
WHERE tb.IsActive = 1 
    AND ISNULL(tbc.BronzeIsActive,1) = 1
GROUP BY 
	SourceSystemName,
    SourceSystemType, 
    SourceContainerName,
    SourceObjectName,
    TargetTableName,
	ImportType,
    PartitionedColumn, 
    AdditionalFilters,
	DeltaColumnName,
	DeltaColumnType,
	DeltaColumnMaxValue,
	Id
END