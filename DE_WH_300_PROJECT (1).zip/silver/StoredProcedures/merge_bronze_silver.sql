CREATE PROC silver.merge_bronze_silver
@PK VARCHAR(100),
--@col_list varchar(300),
@source_table_name varchar(300),
@target_table_name varchar(300)

AS
BEGIN

DECLARE @statement NVARCHAR(1000);

SET @statement = N'

MERGE '+ @target_table_name +' AS TARGET
USING '+ @source_table_name +' AS SOURCE 
ON (TARGET.'+ @PK +' = SOURCE.'+ @PK +') 
WHEN MATCHED AND TARGET.BP <> SOURCE.BP OR TARGET.SEX <> SOURCE.SEX 
THEN UPDATE SET TARGET.BP = SOURCE.BP, TARGET.SEX = SOURCE.SEX 
WHEN NOT MATCHED BY TARGET 
THEN INSERT (BP, SEX) VALUES (SOURCE.BP, SOURCE.SEX)
'
PRINT(@statement)
execute sp_executesql @statement

END;