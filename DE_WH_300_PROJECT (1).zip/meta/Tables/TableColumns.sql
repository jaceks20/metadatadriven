CREATE TABLE [meta].[TableColumns] (

	[TablesBronzeId] bigint NULL, 
	[ColumnName] varchar(100) NULL, 
	[BronzeIsActive] int NULL, 
	[SilverLogic] varchar(100) NULL, 
	[SilverIsActive] int NULL, 
	[GoldLogic] varchar(100) NULL, 
	[GoldIsActive] int NULL
);