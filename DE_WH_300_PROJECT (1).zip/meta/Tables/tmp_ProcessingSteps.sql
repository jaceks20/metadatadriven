CREATE TABLE [meta].[tmp_ProcessingSteps] (

	[TableId] bigint NOT NULL, 
	[Status] int NULL, 
	[CreateDate] datetime2(2) NULL, 
	[Layer] varchar(10) NULL, 
	[ContainerPath] varchar(1000) NULL
);